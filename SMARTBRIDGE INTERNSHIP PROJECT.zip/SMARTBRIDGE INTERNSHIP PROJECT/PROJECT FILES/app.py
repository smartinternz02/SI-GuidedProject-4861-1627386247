# -*- coding: utf-8 -*-
"""
Created on Sat Jul 31 22:16:44 2021

@author: dell
"""

from flask import Flask, request, render_template
from joblib import load


app= Flask(__name__)

model=load('power_prediction.sav')

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/y_predict',methods=['POST'])
def y_predict():
    x_test=[[x for x in request.form.values()]]
    print(x_test)
   
    prediction=model.predict(x_test)
    print(prediction)
    output=prediction[0]
    print(output)
    
    return render_template('index.html',prediction_text='{} KW'.format(output))



if __name__ == '__main__':
    app.run(debug=True)