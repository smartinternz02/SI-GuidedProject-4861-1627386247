# -*- coding: utf-8 -*-
"""
Created on Mon Aug  2 22:23:32 2021

@author: dell
"""
import numpy as np
from flask import Flask, request, jsonify, render_template
import requests

import json
# NOTE: you must manually set API_KEY below using information retrieved from your IBM Cloud account.
API_KEY = "lP9bpXtbwV4wnpT87CYg63Xg63zD6Hf1xWa1gpqSjsMB"
token_response = requests.post('https://iam.cloud.ibm.com/identity/token', data={"apikey": API_KEY, "grant_type": 'urn:ibm:params:oauth:grant-type:apikey'})
mltoken = token_response.json()["access_token"]
print("mltoken",mltoken)

header = {'Content-Type': 'application/json', 'Authorization': 'Bearer ' + mltoken}

# NOTE: manually define and pass the array(s) of values to be scored in the next line


app= Flask(__name__)

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/y_predict',methods=['POST'])
def y_predict():
    
   x_test=[[x for x in request.form.values()]]
   print(x_test) 
   
   payload_scoring = {"input_data": [{"field": [["Wind Speed (m/s)","Theoretical_Power_Curve (KWh)"]], 
                                   "values": x_test}]} 
   response_scoring = requests.post('https://us-south.ml.cloud.ibm.com/ml/v4/deployments/1c56dbeb-8a46-43a4-a1da-8855342cd858/predictions?version=2021-08-05', json=payload_scoring, headers={'Authorization': 'Bearer ' + mltoken})
   print("Scoring response")
   predictions = response_scoring.json()
   print(predictions)
   output = predictions['predictions'][0]['values'][0][0]
   print(output)

   return render_template('index.html', prediction_text='{} KW'.format(output))


if __name__ == '__main__':
    app.run(debug=True)

